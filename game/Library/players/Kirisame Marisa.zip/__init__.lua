Include'THlib\\player\\marisa\\marisa.lua'
AddPlayerToPlayerList('Kirisame Marisa','marisa_player','Marisa')