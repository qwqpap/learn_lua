Include'THlib\\player\\sakuya\\sakuya.lua'
AddPlayerToPlayerList('Izayoi Sakuya','sakuya_player','Sakuya')