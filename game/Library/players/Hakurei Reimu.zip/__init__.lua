Include'THlib\\player\\reimu\\reimu.lua'
AddPlayerToPlayerList('Hakurei Reimu','reimu_player','Reimu')